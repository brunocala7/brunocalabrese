public class productoDeCalefaccion extends productoElectrico{
    private int wattsDePotenciaMax;

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoDeCalefaccion(){
        super();
        this.wattsDePotenciaMax = 15;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    @Override
    public float calcularPrecioFinal() {
        setPrecioFinal(getCosto() + getPorcentajeGanancia());
        return getPrecioFinal();
    }

    @Override
    public float calcularGananciaObtenida() {
        if (getCantDiasDeGarantia() == 365){
            setPorcentajeGanancia(45);
        } else if(getCantDiasDeGarantia() <= 60){
            setPorcentajeGanancia(15);
        }
        return getPorcentajeGanancia();
    }

    @Override
    public String tipoDeProducto() {
        return String;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

}
