public abstract class productoAlimenticio extends productoDeSuper{
    private int cantDiasParaVencerse;
    private static int descuento;

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoAlimenticio(){
        super();
        this.cantDiasParaVencerse = 42;
        descuento = 20;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public int getcantDiasParaVencerse() {return cantDiasParaVencerse;}
    public static int getDescuento() {return descuento;}


    public void setCantDiasParaVencerse(int cantDiasParaVencerse) {this.cantDiasParaVencerse = cantDiasParaVencerse;}


}
