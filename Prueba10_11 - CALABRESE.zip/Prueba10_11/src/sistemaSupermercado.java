import java.util.ArrayList;

public class sistemaSupermercado {
    private String nombre;
    ArrayList<String> productosALaVenta = new ArrayList<String>();
    productosALaVenta.add("Manzana");
    productosALaVenta.add("Yogurt");
    productosALaVenta.add("Leche");
    ArrayList<String> productosVendidos = new ArrayList<String>();
    productosVendidos.add("Garrapiñada");
    productosVendidos.add("Galletitas");
    productosVendidos.add("Gaseosa");

    public interface SistemaDeVentas {
        public float gananciaTotalObtenida();
        public float ingresosTotales();
        public int cantidadDeProductosVendidos();
        public void agregarProductoVendido();
    }
}
