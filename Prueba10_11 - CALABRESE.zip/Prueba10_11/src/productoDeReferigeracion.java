class productoDeRefrigeracion extends productoElectrico{
    private int litrosDeCapacidad;

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoDeRefrigeracion(){
        super();
        this.litrosDeCapacidad = 1500;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    @Override
    public float calcularPrecioFinal() {
        setPrecioFinal(getCosto() + getPorcentajeGanancia());
        return getPrecioFinal();
    }

    @Override
    public float calcularGananciaObtenida() {
        if (getCantDiasDeGarantia() == 365){
            setPorcentajeGanancia(45);
        } else if(getCantDiasDeGarantia() <= 60){
            setPorcentajeGanancia(15);
        }
        return getPorcentajeGanancia();
    }

    @Override
    public String tipoDeProducto() {
        return String;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

}
