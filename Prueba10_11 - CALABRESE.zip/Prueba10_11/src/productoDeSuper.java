public abstract class productoDeSuper implements Producto {
    private String nombre;
    private String origen;
    private int codigo;
    private float costo;
    private float porcentajeGanancia;
    private float precioFinal;

/* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoDeSuper(){
        this.nombre = "Manzana";
        this.origen = "verduleria";
        this.codigo = 18299392;
        this.costo = 25;
        this.porcentajeGanancia = 20;
        this.precioFinal = 2500;
    }
    public productoDeSuper(String Nnombre, String Norigen, int Ncodigo, float Ncosto, float NporcentajeGanancia, float NprecioFinal){
        this.nombre = Nnombre;
        this.origen = Norigen;
        this.codigo = Ncodigo;
        this.costo = Ncosto;
        this.porcentajeGanancia = NporcentajeGanancia;
        this.precioFinal = NprecioFinal;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public String getNombre() {return nombre;}
    public String getOrigen() {return origen;}
    public int getCodigo() {return codigo;}
    public float getCosto() {return costo;}
    public float getPorcentajeGanancia() {return porcentajeGanancia;}
    public float getPrecioFinal() {return precioFinal;}

    public void setNombre(String nombre) {this.nombre = nombre;}
    public void setOrigen(String origen) {this.origen = origen;}
    public void setCodigo(int codigo) {this.codigo = codigo;}
    public void setCosto(float costo) {this.costo = costo;}
    public void setPorcentajeGanancia(float porcentajeGanancia) {this.porcentajeGanancia = porcentajeGanancia;}
    public void setPrecioFinal(float precioFinal) {this.precioFinal = precioFinal;}

}
