public class productoNoPerecedero extends productoAlimenticio{
    private float mgDeSodio;

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoNoPerecedero(){
        super();
        this.mgDeSodio = 50;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    @Override
    public float calcularPrecioFinal() {
        setPrecioFinal(getCosto() + getPorcentajeGanancia());
        return getPrecioFinal();
    }

    @Override
    public float calcularGananciaObtenida() {
        if (getcantDiasParaVencerse() <= 90){
            setPorcentajeGanancia(10);
        } else if(getcantDiasParaVencerse() > 90) {
            setPorcentajeGanancia(25);
        }
        return getPorcentajeGanancia();
    }

    @Override
    public String tipoDeProducto() {
        return String;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

}