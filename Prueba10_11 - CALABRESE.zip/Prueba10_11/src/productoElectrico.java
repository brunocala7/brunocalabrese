public abstract class productoElectrico extends productoDeSuper{
    private int cantDiasDeGarantia;
    private static int recargo_por_envio;

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public productoElectrico(){
        super();
        this.cantDiasDeGarantia = 200;
        recargo_por_envio = 350;
    }

    /* |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*/

    public int getCantDiasDeGarantia() {return cantDiasDeGarantia;}
    public static int getRecargo_por_envio() {return recargo_por_envio;}


    public void setCantDiasDeGarantia(int cantDiasDeGarantia) {this.cantDiasDeGarantia = cantDiasDeGarantia;}
}
